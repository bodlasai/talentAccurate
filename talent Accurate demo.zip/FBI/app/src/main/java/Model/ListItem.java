package Model;

import android.widget.ImageView;
import android.widget.TextView;

public class ListItem {


    private String badgephoto;
    private String value;

    public ListItem() {
        this.badgephoto=badgephoto;
        this.value=value;
    }

    public String getBadgephoto() {
        return badgephoto;
    }

    public void setBadgephoto(String badgephoto) {
        this.badgephoto = badgephoto;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }









}

