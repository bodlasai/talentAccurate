package com.example.fbi;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class RecyclerAdapter extends RecyclerView.Adapter {
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
    {

        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int i) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public static  class  imageviewholder extends RecyclerView.ViewHolder
    {
        ImageView badgephoto;
        TextView badgescore;

        public imageviewholder(@NonNull View itemView) {
            super(itemView);

            badgephoto=itemView.findViewById(R.id.imagevalue_structure);
            badgescore=itemView.findViewById(R.id.structure_credit_value);
        }
    }



}
