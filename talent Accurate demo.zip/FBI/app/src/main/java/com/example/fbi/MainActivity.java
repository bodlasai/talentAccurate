package com.example.fbi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private EditText emailaddress;
    private  EditText userpassword;
    private Button loginbutton;
    private String baseurl="http://devapi.talentaccurate.com/cview/login/json?username=";
    private  String middle="&password=";
    private String apivalue="&apikey=wf2537572d6f7b795a713c5e6w";

    private String sbase="http://devapi.talentaccurate.com/eview/rockstar/";
    private String extra="/json?";
    private String sapi="&apikey=wf2537572d6f7b795a713c5e6w&sessionid=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        emailaddress=(EditText) findViewById(R.id.email);
        userpassword=(EditText) findViewById(R.id.password);
        loginbutton=(Button) findViewById(R.id.login);

        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String myurl=baseurl+emailaddress.getText().toString()+middle+userpassword.getText().toString()+apivalue;
                Log.i("myurl","myurl"+myurl);


                JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.POST, myurl, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {

                                try
                                {
                                    String apivalue1=response.getString("apivalue");
                                    Log.i("api","api"+apivalue1);
                                    JSONObject co= new JSONObject(apivalue1);
                                    String username=co.getString("username");
                                    //String email=co.getString("email");
                                    //Log.i("email","email"+email);
                                    String session=co.getString("sessionid");
                                    Log.i("s","s"+session);

                                    String complete=sbase+username+extra+sapi+session;
                                    Log.i("complete","complete url"+complete);

                                    Register(complete);



                                }
                                catch (JSONException e)
                                {
                                    e.printStackTrace();
                                }
                                Log.i("Json","Json"+response);
                            }
                        },
                        new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.i("someting went wrong","error");
                    }
                }


                );

                MySingelton.getInstance(MainActivity.this).addToRequestQue(jsonObjectRequest);


            }
        });
    }

    private void Register(String complete) {

        JsonObjectRequest jsonObjectRequest1= new JsonObjectRequest(Request.Method.POST, complete, null,

                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        Log.i("res","res"+response);
                        try {
                            String apivalues1=response.getString("apivalue");
                            JSONObject so=new JSONObject(apivalues1);
                            Log.i("api","api"+so);
                            String basic=so.getString("basic");
                            JSONObject ba=new JSONObject(basic);

                            String user=ba.getString("username");
                            String email1=ba.getString("email");
                            String country=ba.getString("country");
                            String imageurl=ba.getString("profile_image_link");

                            String credit_status1=so.getString("credit_status");
                            JSONObject credit=new JSONObject(credit_status1);

                            String totalcredits=credit.getString("general_credits");


                            Log.i("basic","basic"+user);


                            String badge=so.getString("badges");

                            Log.i("full","full:"+badge);
                            JSONArray ar= new JSONArray(badge);
//                            ArrayList<List> obarray = new ArrayList<>();
//                            for(int i=0;i<ar.length();i++)
//                            {
//                                JSONObject obs  = ar.getJSONObject(i);
//                                obarray.add(obs);
//                            }
                           // StringBuffer finalBuffer=new StringBuffer();
                            ArrayList<String> datastring=new ArrayList<String>();
                            for(int i=0; i<ar.length(); i++) {
                                //String obstring = "obj"+(i+1);
                                //String mystring[] = new String[100];
                                JSONObject  obj1 = ar.getJSONObject(i);
                                //   String value1=obj1.getJSONObject(0).getString("BADGE_IMAGE_URL");
                                String badgeurl = obj1.getString("BADGE_IMAGE_URL");

                                 datastring.add(badgeurl);
                               // Log.i("badgeurl", "bagdeurl" + badgeurl);
//                                Log.i("obj", "obj" + obj1);
                                // finalBuffer.append(badgeurl);


                            }
                            Log.i("data","sdata"+datastring);

//                            for(int j=1;j<=ar.length();j++)
//                            {
//                                String obs="ob1"+(j+1);
//                                String a1=datastring.get(j);
//                                Log.i("a1","a1"+a1);
//                            }

                            //String a=finalBuffer.toString();
                          //  Log.i("ok","ok"+a[0]);





                            Intent newintent= new Intent(MainActivity.this,profileavtivity.class);
                            newintent.putExtra("username",user);
                            newintent.putExtra("email",email1);
                            newintent.putExtra("country",country);
                            newintent.putExtra("imageurl",imageurl);
                           newintent.putExtra("totalcredits",totalcredits);
                           //newintent.putExtra("badgeurl",badgeurl);
                            startActivity(newintent);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }

        );
        MySingelton.getInstance(MainActivity.this).addToRequestQue(jsonObjectRequest1);



    }
}
