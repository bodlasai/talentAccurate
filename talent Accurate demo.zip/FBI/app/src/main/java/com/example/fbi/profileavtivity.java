package com.example.fbi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class profileavtivity extends AppCompatActivity {
    private TextView profileusername;
    private  TextView profileemail;
    private  TextView profilelocation;
    private  TextView credits;
    private ImageView profilephoto;
    private ImageView profilebadge1;
    private ImageView profilebadge2;
    private ImageView profilebadge3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profileavtivity);
        profileusername=(TextView) findViewById(R.id.profile_name);
        profileemail=(TextView) findViewById(R.id.emailvalues);
        profilelocation=(TextView) findViewById(R.id.locationvalue);
        credits=(TextView) findViewById(R.id.credetsvalues);
        profilephoto=(ImageView) findViewById(R.id.photo);
        profilebadge1=(ImageView) findViewById(R.id.badge1);
        profilebadge2=(ImageView) findViewById(R.id.badge2);


        String username=getIntent().getExtras().getString("username");
        String email=getIntent().getExtras().getString("email");
        String location=getIntent().getExtras().getString("country");
        String democredit=getIntent().getExtras().getString("totalcredits");
        String  userphoto=getIntent().getExtras().getString("imageurl");
        String badge1=getIntent().getExtras().getString("badgeurl");




        profileusername.setText(username);
        profileemail.setText(email);
        profilelocation.setText(location);
        credits.setText(democredit);
        Picasso.get()
                .load(userphoto)
                .placeholder(R.drawable.defaultimage)
                .error(R.drawable.defaultimage)
                .into(profilephoto);
        Picasso.get()
                .load(badge1)
                .placeholder(R.drawable.defaultimage)
                .error(R.drawable.defaultimage)
                .into(profilebadge1);


    }

    public void move(View view) {

        Intent demointent= new Intent(profileavtivity.this,badges.class);
        startActivity(demointent);
    }


    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {


        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.main_menu,menu);

        return  true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
         super.onOptionsItemSelected(item);

         if(item.getItemId()==R.id.logout_button)
         {
             Intent startintent= new Intent(profileavtivity.this,MainActivity.class);
             startActivity(startintent);
         }

        return true;
    }

}
