package com.example.fbi;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import Adapter.MyAdapter;
import Model.ListItem;

public class badges extends AppCompatActivity {
   // private static Object RecyclerView ="" ;
    private RecyclerView recyclerView;
    //private String  RecyclerViewAdapter;

    private  RecyclerView.LayoutManager layoutManager;

    private  final String json_url="http://devapi.talentaccurate.com/eview/rockstar/bodlasai924/json?&apikey=wf2537572d6f7b795a713c5e6w&sessionid=44ab69abcd7897ff960786fc6b81d2fac64cf85d96873910c099c1d1e40889c653efb79c4c5ecff5fcd0082fa0bb4b9e82271d9bbdadd9ea3568c9815b37633abf723f1b114a5cbffe13e422c1ca0f713d2edd40f09a5528bef141416d8d7864";
    private JsonArrayRequest request;
    private RequestQueue requestQueue;
    private List<ListItem> demo = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        demo= new ArrayList<>();
        recyclerView=(RecyclerView) findViewById(R.id.recycleid);
//        layoutManager=new LinearLayoutManager(this);
//        recyclerView.setHasFixedSize(true);
//        recyclerView.setLayoutManager(layoutManager);
        jsonrequest();

    }

    private void jsonrequest() {

        request = new JsonArrayRequest(Request.Method.POST,json_url,null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {


//                try {
//                    String apivalues1= (String) response.getString(Integer.parseInt("apivalue"));
//                    JSONObject js= new JSONObject(apivalues1)
//
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }

                for(int i=0;i<response.length();i++)
                {

                    try {


                        String apivalues1= (String) response.getString(Integer.parseInt("apivalue"));
                        JSONObject so=new JSONObject(apivalues1);
                        String basic=so.getString("badges");
                        JSONObject ba=new JSONObject(basic);
                        JSONObject  jsonObject = null;
                        ba = response.getJSONObject(i);

                        ListItem anime=new ListItem();
                        anime.setValue(ba.getString("BADGE_COUNT"));
                        anime.setBadgephoto(ba.getString("BADGE_IMAGE_URL"));
                        demo.add(anime);
                        Log.i("d","demo"+demo);
                    }
                    catch (Exception e)
                    {

                        e.printStackTrace();
                    }
                }

               setRecycleviewAdapter(demo);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
        });

        requestQueue = Volley.newRequestQueue(badges.this);
        requestQueue.add(request);


    }

    private void setRecycleviewAdapter(List<ListItem> demo) {
        MyAdapter myadapter= new MyAdapter(this, (List<ListItem>) demo);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(myadapter);
    }


}
